﻿namespace LoanManagementAPI.DTOs
{
    public class LoanDTO
    {
    }
}
