﻿namespace LoanManagementAPI.DTOs
{
    public class UserDTO
    {
    }
}
