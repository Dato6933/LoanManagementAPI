﻿namespace LoanManagementAPI.Services
{
    public class LoanService
    {
    }
}
